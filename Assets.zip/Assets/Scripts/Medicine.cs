﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Medicine : MonoBehaviour
{
    /* 3 переменные, которые могут хранить НЕ целое число. Пока пустые. */
    float x;
    float y;
    float z;
    Transform tr;
    void Start()
    {
        tr = GetComponent<Transform>(); 
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnCollisionEnter(Collision other)
    {
        /*
        Random.Range(-4f, 4f) - метод (функция), который создает рандомное не целое число.
        Принимает 2 аргумента - предел от какого до какого числа создавать число. Например, от -4.0f до 4.0f. 
        В переменные x, y, z записываем раномные числа.
        */
        x = Random.Range(-4f, 4f);
        z = Random.Range(-4f, 4f);
        if(other.gameObject.tag == "Player")
        {
            Instantiate(gameObject, new Vector3(x, 0.5f, z), tr.rotation);
            Destroy(gameObject);
        }
    }
}