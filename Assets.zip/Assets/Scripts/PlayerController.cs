﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    /* 3 переменные, которые могут хранить НЕ целое число. Пока пустые. */
    Transform tr;
    void Start()
    {
        print("Собери 5 аптечек чтобы выжить");
        tr = GetComponent<Transform>(); 
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("s"))
        {
            transform.Translate(0, 0, -0.5f);
        }
        if (Input.GetKeyDown("w"))
        {
            transform.Translate(0, 0, 0.5f);
        }
        if (Input.GetKeyDown("a"))
        {
            transform.Translate(-0.5f, 0, 0);
        }
        if (Input.GetKeyDown("d"))
        {
            transform.Translate(0.5f, 0, 0);
        }
    }
    int x = 3;
    int y = 0;
    void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.tag == "Bomb")
        {
            x = x - 1;
            print("Здоровье: " + x);
            if(x==0){
                print("Вас подорвали");
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }

        }
        if(other.gameObject.tag == "Medicine")
        {
            x = x + 1;
            print("Здоровье: " + x);
            y = y + 1;
            if(y==5){
                print("Вы выжили");
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }

        }
    }
}